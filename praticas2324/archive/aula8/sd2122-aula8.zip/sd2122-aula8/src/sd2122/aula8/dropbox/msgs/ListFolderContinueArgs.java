package sd2122.aula8.dropbox.msgs;

public record ListFolderContinueArgs(String cursor) {
}
