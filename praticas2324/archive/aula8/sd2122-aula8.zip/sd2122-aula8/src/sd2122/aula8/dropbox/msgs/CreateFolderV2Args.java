package sd2122.aula8.dropbox.msgs;

public record CreateFolderV2Args(String path, boolean autorename) {
}