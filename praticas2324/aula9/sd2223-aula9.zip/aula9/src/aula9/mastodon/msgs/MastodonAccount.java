package aula9.mastodon.msgs;

public record MastodonAccount(String id, String username) {
}
